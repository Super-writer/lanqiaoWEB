package LX.bean.BY;

import java.util.List;

public class BY_PageBean {
    private List<zj> data;

    public List<zj> getData() {
        return data;
    }

    public void setData(List<zj> data) {
        this.data = data;
    }
}
