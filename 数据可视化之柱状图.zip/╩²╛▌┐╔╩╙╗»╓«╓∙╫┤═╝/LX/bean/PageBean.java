package LX.bean;

import java.util.List;

public class PageBean {
    private List<yy> data;//查询到的数据

    public List<yy> getData() {
        return data;
    }

    public void setData(List<yy> data) {
        this.data = data;
    }
}
